# Handwritten-Digit-Recognition

Recognises handwritten digits using KNN Model. Trained using MNIST Dataset.
